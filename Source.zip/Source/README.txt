Compile with "make" (uses GNU compiler)

Run with a.exe (or ./a.out depending on system)